const express = require("express");
const { MongoClient } = require("mongodb");

const app = express();

const url = "mongodb+srv://test:test@osmancluster.xy12abc.mongodb.net/mekanDB?retryWrites=true&w=majority";
const client = new MongoClient(url);

async function start() {
  try {
    await client.connect();
    console.log("Veritabanına bağlanıldı.");

    const db = client.db("mekanDB");
    const mekanlar = db.collection("mekanlar");

    const veriler = [
      { ad: "Lavanta Kafe", adres: "Isparta Merkez", puan: 4.5 },
      { ad: "Gül Bahçesi Restaurant", adres: "Isparta Merkez", puan: 4.3 },
      { ad: "Manzara Cafe", adres: "Isparta Merkez", puan: 4.4 },
      { ad: "Pınaraltı Pastanesi", adres: "Isparta Merkez", puan: 4.2 },
      { ad: "Gökçay Büfe", adres: "Isparta Merkez", puan: 4.6 }
    ];

    const kontrol = await mekanlar.findOne();
    if (!kontrol) {
      await mekanlar.insertMany(veriler);
      console.log("Mekanlar veritabanına eklendi.");
    } else {
      console.log("Mekanlar zaten kayıtlı.");
    }

    app.get("/mekanlar", async (req, res) => {
      const liste = await mekanlar.find().toArray();
      res.json(liste);
    });

    app.listen(3000, () => {
      console.log("Sunucu 3000 portunda çalışıyor.");
    });
  } catch (err) {
    console.log("Hata:", err);
  }
}

start();
